# Astro Screenshare Tool

This plugin was coded a while ago now and isn't made very well. However, it can be used for some method ideas if you are coding similar tools! Good luck!

Astro is a minecraft screenshare tool made with python that aims to help players & staff catch cheaters.

![Astro Example](https://i.imgur.com/RsayBSs.png)


